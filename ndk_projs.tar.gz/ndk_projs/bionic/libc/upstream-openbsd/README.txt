This directory contains upstream OpenBSD source. You should not edit these
files directly. Make fixes upstream and then pull down the new version of
the file.

TODO: write a script to make this process automated.
