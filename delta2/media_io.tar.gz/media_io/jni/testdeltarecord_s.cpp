#define LOG_NDEBUG 0
#define LOG_TAG "TestDeltaRecord_S"
#include "utils/Log.h"
#include <stdint.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <err.h>                                                                                                                                                                                            
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <binder/ProcessState.h>
#include <testdeltarecord.h>

#define ID_RIFF 0x46464952
#define ID_WAVE 0x45564157
#define ID_FMT  0x20746d66
#define ID_DATA 0x61746164

#define FORMAT_PCM 1


struct wav_header {
    uint32_t riff_id;
    uint32_t riff_sz;
    uint32_t riff_fmt;
    uint32_t fmt_id;
    uint32_t fmt_sz;
    uint16_t audio_format;
    uint16_t num_channels;
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample;
    uint32_t data_id;
    uint32_t data_sz;
};


int32_t singintCnt = 0;
struct wav_header resultHeader;


static void usage(const char *me)
{
	fprintf(stderr,
			"usage:\n"
			"	%s  -o file.wav [-b ]\n",
			me);
}

/*void sigint_handler(int sig)
{
	singintCnt = 1;
	fprintf(stderr, "sigint_handler singintCnt = 1\n");
}
*/

int main(int argc, char**argv)
{
	using namespace android;

	ProcessState::self()->startThreadPool();

	int logCnt = 0;

	int res;
	int blockFlag = 0;
	int frames = 256;
	int channels = 1;
	int readSize = 0;
	int rate = 16000;


	unsigned int resultWriteFrames = 0;

	FILE *filesResult = NULL;
	uint8_t *readBuffer = NULL;
	const char * fileName = NULL;

	while((res = getopt(argc, argv, "o:bh")) != -1 )
	{
		switch(res){
			case 'o':
			{
				fileName = optarg;
			}
				break;
			case 'b':
			{
				blockFlag = 1;	
			}
				break;
			case '?':
			case 'h':
			default:
			{
				usage(argv[0]);
				exit(1);
			}
		}
	}

	if(fileName == NULL)
	{
		fprintf(stderr, "fileName is NULL exit\n");
		exit(1);
	}
	
	filesResult = fopen(fileName, "wb");
    	if (!filesResult) {
        	fprintf(stderr, "Unable to open result file '%s'\n", fileName);
		exit(1);
	}
	else{
        	fprintf(stderr, "open result file '%s' ok\n",  fileName);
	}

	fseek(filesResult, sizeof(struct wav_header), SEEK_SET);

	readSize = 2 * channels * frames;
	readBuffer = (uint8_t *)malloc(readSize + 4);
			
	if(!readBuffer)
	{
        	fprintf(stderr, "Unable to malloc readBuffer \n");
    		fclose(filesResult);
		exit(1);
	}
	else
	{
        	fprintf(stderr, "malloc readBuffer 0x%x\n", (unsigned int)(readBuffer));
	}

	resultHeader.riff_id = ID_RIFF;
	resultHeader.riff_sz = 0;
	resultHeader.riff_fmt = ID_WAVE;
	resultHeader.fmt_id = ID_FMT;
	resultHeader.fmt_sz = 16;
	resultHeader.audio_format = FORMAT_PCM;
	resultHeader.num_channels = channels;
	resultHeader.sample_rate = 16000;

	resultHeader.bits_per_sample = 16;
	resultHeader.byte_rate = (resultHeader.bits_per_sample / 8) * resultHeader.num_channels * resultHeader.sample_rate;
	resultHeader.block_align = resultHeader.num_channels * (resultHeader.bits_per_sample / 8);
	resultHeader.data_id = ID_DATA;

	TestDeltaRecord *record = new TestDeltaRecord(blockFlag);

	record->start();	
	
	fprintf(stderr, "start test ......\n");
	//signal(SIGINT, sigint_handler); 
	
	do{
		int ret;
		
		if(blockFlag)
		{
			ret = record->read(readBuffer, readSize);	
			if(ret != readSize)
			{
				fprintf(stderr, "is error?? block read ret %d != readSize %d\n", ret, readSize);
			}
			else
			{
				if(filesResult)
				{	
        				if (fwrite(readBuffer, 1, readSize, filesResult) != readSize)
					{

						fprintf(stderr, "write result file failed\n");
					}
					else
					{
						resultWriteFrames += frames;
					}
				}			
			}
		}
		else
		{
		 	ret = record->read(readBuffer, readSize);
			if(ret > 0)
			{
				if(filesResult)
				{	
        				if (fwrite(readBuffer, 1, ret, filesResult) != ret)
					{

						fprintf(stderr, "write result file failed\n");
					}
					else
					{
						resultWriteFrames += (ret / (channels * 2));
					}
				}			
			
			}

			if(ret != readSize)
			{
				usleep(((frames * 1000) / rate) * 1000); 
			}
		}

		logCnt += 1;
		if(logCnt >= 30)
		{
			logCnt = 0;
			fprintf(stderr, "write result frames %d\n", resultWriteFrames);
		}
#if 1
		singintCnt += 1;

	}while(singintCnt < 2000);
#else
	//}while(!singintCnt);
#endif
	fprintf(stderr, "test exit\n");
	
	record->pause();	
	delete record;

	if(filesResult)
	{	
    		/* write header now all information is known */
    		resultHeader.data_sz = resultWriteFrames * resultHeader.block_align;
    		resultHeader.riff_sz = resultHeader.data_sz + sizeof(resultHeader) - 8;
    		fseek(filesResult, 0, SEEK_SET);
    		fwrite(&resultHeader, sizeof(struct wav_header), 1, filesResult);
	}


	if(readBuffer)
	{
    		fprintf(stderr, "free readBuffer ....\n");
    		free(readBuffer);
	}
	if(filesResult)
	{
    		fprintf(stderr, "close result files ....\n");
    		fclose(filesResult);
	}


	return 0;
}
