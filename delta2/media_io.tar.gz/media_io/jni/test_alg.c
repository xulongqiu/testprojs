#include <stdio.h>
#include "dlog.h"
#include "alg_interface.h"

int AECForHostInit(void)
{
	log_print(INFO, "test_alg AECForHostInit enter\n");

	//0 is ok
	return 0;
}

void AECForHostFarValid(bool flag)
{
	log_print(INFO, "test_alg AECForHostFarValid %s\n", flag?"true":"false");
	return;
}

int AECForHostMain(struct aecDataParam *param)
{
	unsigned int i,j;
	int64_t	inputLeftSum;
	int64_t	inputRightSum;

	short *farPtr;
	short *nearPtr;
	short *resultPtr;

	log_print(INFO, "test_alg AECForHostMain enter\n");
	log_print(INFO, "aecDataParam nearNum: %d\n",param->nearNum);
	log_print(INFO, "aecDataParam frames: %d\n",param->frames);
	log_print(INFO, "aecDataParam result: 0x%x\n",(unsigned int)param->Result);
	log_print(INFO, "aecDataParam far: 0x%x\n",(unsigned int)param->Far);
	log_print(INFO, "aecDataParam Near0: 0x%x\n",(unsigned int)param->Near[0]);

	if(param->Result == NULL)
	{
		log_print(INFO, "test_alg result buffer is null\n");
		return -1;
	}
	if(param->Far == NULL)
	{
		log_print(INFO, "test_alg Far buffer is null\n");
		return -1;
	}
	if(!param->nearNum || !param->frames)
	{
		log_print(INFO, "test_alg nearNum or frames == 0\n");
		return -1;
	}
	for(i=0; i< param->nearNum; i++)
	{
		if(param->Near[i] == NULL)
		{
			log_print(INFO, "test_alg Near[%d] buffer is null\n", i);
			return -1;
		}
	}

	farPtr = param->Far;
	resultPtr = param->Result;

	for(i = 0; i < param->frames; i++)
	{
		inputLeftSum = *farPtr++;
		inputRightSum = *farPtr++;

		for(j=0; j<param->nearNum; j++)
		{
			nearPtr = (param->Near[j] + (i<<1));
				
			inputLeftSum += *nearPtr++;
			inputRightSum += *nearPtr;
		}

		*resultPtr++ = (short)((inputLeftSum + inputRightSum) / ((param->nearNum + 1) * 2));
	}

	return 0;
}

void ForHostAECExit(void)
{
	log_print(INFO, "test_alg ForHostAECExit enter\n");
}

