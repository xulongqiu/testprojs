#ifndef __AUDIO_RECORD_H__
#define __AUDIO_RECORD_H__

#ifdef __cplusplus
extern "C" {
#endif

struct record_param {
	int32_t stream_channels;
	int32_t valid_channels;
	int32_t echo_channels;
	int32_t echo_offset;
	int32_t samplebits;
	int32_t periodsize;
	int32_t samplerate;
};


int32_t record_stream_param(struct record_param **param);
int32_t record_stream_start(void);
int32_t record_stream_close(void);
ssize_t record_stream_read(void* buffer, size_t bytes);
int32_t record_stream_mute(bool state);

#ifdef __cplusplus
}
#endif

#endif

