#ifndef __ALG_INTERFACE_H__
#define __ALG_INTERFACE_H__
#include <stdbool.h> 

#ifdef __cplusplus
extern "C" {
#endif

struct aecDataParam{
	unsigned int nearNum;
	unsigned int frames;
	short *Result;
	short *Far;
	short *Near[4];
};

void AECForHostFarValid(bool flag);
int AECForHostInit(void);
int AECForHostMain(struct aecDataParam *);
void ForHostAECExit(void); 

#ifdef __cplusplus
}
#endif

#endif
