
#ifndef ANDROID_TESTDELTAMEDIAPLAYER_H
#define ANDROID_TESEDELTAMEDIAPLAYER_H


namespace android {


class DeltaMediaPlayer;
class ProxyListener;


enum test_player_type {
	TEST_PLAYER_TYPE_URL =      (1),
	TEST_PLAYER_TYPE_STREAM =    (1 << 1),
}; 


class TestDeltaMediaPlayer
{
public:

    TestDeltaMediaPlayer(int32_t type, int32_t source );
    ~TestDeltaMediaPlayer();
    status_t	init(const char *url, int32_t rate = 48000, int32_t channels = 2);
    
    size_t	write(const char *buf, int size, int64_t pts = 0);

    bool	start();
    bool 	pause();
    bool	stop();
    bool	reset();
    bool	flush();
    status_t	release();

    status_t	seekTo(int msec);

private:
    sp<DeltaMediaPlayer> mPlayer;
    sp<ProxyListener> mListener;
};

}

#endif
