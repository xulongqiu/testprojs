#ifndef ANDROID_TESTDELTARECORD_H
#define ANDROID_TESTDELTARECORD_H



namespace android {

class DeltaRecord;
class TestDeltaRecordListener;


class TestDeltaRecord 
{
public:
	TestDeltaRecord(uint32_t id);
	~TestDeltaRecord();
	void release();

	//DeltaRecordListener notify
	
	status_t start();
	status_t flush();
	status_t pause();
	int32_t read(uint8_t *buffer, int32_t len);


private:

	sp<DeltaRecord> mDeltaRecord;
	sp<TestDeltaRecordListener> mTestDeltaRecordListener;
};

}

#endif
