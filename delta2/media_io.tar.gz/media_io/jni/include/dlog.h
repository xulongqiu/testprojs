#ifndef __ALGLOG_H__
#define __ALGLOG_H__

#ifdef __cplusplus
extern "C" {
#endif

#include <sys/types.h>
#include <stdio.h>

enum log_level {
    DEBUG = 0,
    INFO = 1,
    WARNING = 2,
    ERROR = 3,
    FATAL = 4,
    LOG_MIN = 0,
    LOG_MAX = 4,
};

void log_print(int level, const char *format, ...);

#ifdef __cplusplus
}
#endif

#endif
