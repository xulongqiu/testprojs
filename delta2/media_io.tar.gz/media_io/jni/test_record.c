#define LOG_NDEBUG 0
#define LOG_TAG "TestRecord"
//#include "utils/Log.h"
#include <stdint.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <err.h>                                                                                                                                                                                            
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
//#include <cutils/properties.h>
#include "alg_interface.h"
#include "audio_record.h"

#define ID_RIFF 0x46464952
#define ID_WAVE 0x45564157
#define ID_FMT  0x20746d66
#define ID_DATA 0x61746164

#define FORMAT_PCM 1

//dont change it
#define LOCAL_FAR_FIFO_NAME "/mnt/asec/aec_far_fifo"

char file_name[20];

struct wav_header {
    uint32_t riff_id;
    uint32_t riff_sz;
    uint32_t riff_fmt;
    uint32_t fmt_id;
    uint32_t fmt_sz;
    uint16_t audio_format;
    uint16_t num_channels;
    uint32_t sample_rate;
    uint32_t byte_rate;
    uint16_t block_align;
    uint16_t bits_per_sample;
    uint32_t data_id;
    uint32_t data_sz;
};

struct aecDataParam dataParam;
struct wav_header resultHeader;
struct wav_header testHeader;

unsigned int capturing = 1;


#define TEST_FRAMES 512


static void usage(const char *me)
{
	fprintf(stderr,
			"usage:\n"
			"	%s -f ref.wav -r result.wav -a near0.wav [-b near1.wav -c near2.wav -d near3.wav] [-t -l]\n",
			me);
}

void sigint_handler(int sig)
{
	    capturing = 0;
}


int main(int argc, char**argv)
{
	int res;
	const char * refFileName = NULL;
	const char * resultFileName = NULL;
	const char * nearFileName[4];

	unsigned int nearFileNum = 0;
	
	short *refBuffer = NULL;
	short *streamReadBuffer = NULL;
	short *resultBuffer = NULL;
	short *nearBuffer [4 + 1];

	FILE *filesRef = NULL;
	FILE *filesResult = NULL;
    	FILE *filesNear[4];

	//8 channel near 2 channel ref
    	FILE *filesTest[5];
	
	unsigned int i;
	unsigned int refReadSize = 0;
	unsigned int nearReadSize = 0;
	unsigned int streamReadSize = 0;
	unsigned int resultReadSize = 0;
	
	unsigned int resultWriteFrames = 0;
	unsigned int testWriteFrames = 0;
	bool	inputStreamFlag = false;
	bool	outputStreamFlag = false;
	bool	streamTestFlag = false;
	bool	localFarFlag = false;
	bool	localFarStreamFlag = false;
	struct record_param *recordParam = NULL;

	int pipeFd = -1;

	char cmd[64];
	
	fprintf(stderr, "test begin,,,,\n");
	
	

	for(i = 0; i<4; i++)
	{
		filesNear[i] = NULL;
		nearFileName[i] = NULL;
	}
	for(i = 0; i<5; i++)
	{
		filesTest[i] = NULL;
		nearBuffer[i] = NULL;
	}

	while((res = getopt(argc, argv, "f:r:a:b:c:d:htl")) != -1 )
	{
		switch(res){
			case 'f':
			{
				refFileName = optarg;
			}
				break;
			case 'r':
			{
				resultFileName = optarg;
			}
				break;
			case 'a':
			{
				nearFileName[nearFileNum] = optarg;
				nearFileNum += 1;	
			}
				break;
			
			case 'b':
			{
				nearFileName[nearFileNum] = optarg;
				nearFileNum += 1;	
			}
				break;
		
		
			case 'c':
			{
				nearFileName[nearFileNum] = optarg;
				nearFileNum += 1;	
			}
				break;
			case 'd':
			{
				nearFileName[nearFileNum] = optarg;
				nearFileNum += 1;	
			}
				break;
			case 'l':
			{
				localFarFlag = true;	
			}
				break;
			case 't':
			{
				streamTestFlag = true;	
			}
				break;
			case '?':
			case 'h':
			default:
			{
				usage(argv[0]);
				exit(1);
			}
		}
	}

	if(refFileName == NULL)
	{
		if(localFarFlag)
		{
			fprintf(stderr, "refFileName is NULL; using local FIFO Far stream.....\n");
		}
		else	
		{
			fprintf(stderr, "localFarFlag is false; using record.....\n");
		}
		//TODO add ref stream init
	}
	else
	{
		filesRef = fopen(refFileName, "rb");
    		if (!filesRef) {
        		fprintf(stderr, "Unable to open ref file '%s'\n", refFileName);
			goto exit;
		}
		else{
        		fprintf(stderr, "open ref file '%s' ok\n", refFileName);
		}
	
		fseek(filesRef, sizeof(struct wav_header), SEEK_SET);

		refReadSize = 2 * 2 * TEST_FRAMES;
		refBuffer = malloc(refReadSize + 4);

		if(!refBuffer)
		{
        		fprintf(stderr, "Unable to malloc refBuffer \n");
			goto exit;	
		}
		else
		{
        		fprintf(stderr, "malloc refBuffer 0x%x\n", (unsigned int)(refBuffer));
		}
	}


	if(nearFileNum == 0)
	{
		fprintf(stderr, "nearFileNum == 0; using record.....\n");
		
		//TODO add record stream init
		record_stream_param(&recordParam);
	
		if(localFarFlag)
		{
			fprintf(stderr, "localFarFlag is true; echo_channels %d->0\n", recordParam->echo_channels);
			recordParam->echo_channels = 0;
		}

		fprintf(stderr, "recordParam.stream_channels %d\n", recordParam->stream_channels);
		fprintf(stderr, "recordParam.valid_channels %d\n", recordParam->valid_channels);
		fprintf(stderr, "recordParam.echo_channels %d\n", recordParam->echo_channels);
		fprintf(stderr, "recordParam.echo_offset %d\n", recordParam->echo_offset);
		fprintf(stderr, "recordParam.samplebits %d\n", recordParam->samplebits);
		fprintf(stderr, "recordParam.periodsize %d\n", recordParam->periodsize);
		fprintf(stderr, "recordParam.samplerate %d\n", recordParam->samplerate);

		//16bit 2ch frames
		nearReadSize = 2 * 2 * recordParam->periodsize;

		//valid_channels <= 10
		for(i = 0; i < ((recordParam->valid_channels) >> 1); i++)
		{
			nearBuffer[i] = malloc(nearReadSize + 4);		
				
			if(!nearBuffer[i])
			{
        			fprintf(stderr, "Unable to malloc nearBuffer[%d] \n", i);
				goto exit;	
			}
			else
			{
        			fprintf(stderr, "malloc nearBuffer[%d] 0x%x\n", i, (unsigned int)(nearBuffer[i]));
			}
			
		}

		if(recordParam->echo_channels > 2)
		{
        		fprintf(stderr, "Unable to supprot echo chennels > 2\n");
			goto exit;
		}

		streamReadSize = 2 * recordParam->stream_channels * recordParam->periodsize;
		streamReadBuffer = malloc(streamReadSize + 4);

		if(!streamReadBuffer)
		{
        		fprintf(stderr, "Unable to malloc streamReadBuffer \n");
			goto exit;	
		}
		else
		{
        		fprintf(stderr, "malloc streamReadBuffer 0x%x\n", (unsigned int)(streamReadBuffer));
		}
	
		if(streamTestFlag)
		{
			fprintf(stderr, "streamTestFlag is true, init test file\n");
  
			testHeader.riff_id = ID_RIFF;
			testHeader.riff_sz = 0;
			testHeader.riff_fmt = ID_WAVE;
			testHeader.fmt_id = ID_FMT;
			testHeader.fmt_sz = 16;
			testHeader.audio_format = FORMAT_PCM;
			testHeader.num_channels = 2;
			testHeader.sample_rate = 16000;

			testHeader.bits_per_sample = 16;
			testHeader.byte_rate = (testHeader.bits_per_sample / 8) * 2 * testHeader.sample_rate;
			testHeader.block_align = 2 * (testHeader.bits_per_sample / 8);
			testHeader.data_id = ID_DATA;

			//vaild_channels <= 10
			for(i=0; i< (recordParam->valid_channels >> 1); i++)
			{
				sprintf(file_name, "sub_file%d.wav\0", i);
    				filesTest[i] = fopen(file_name, "wb");

    				if (!filesTest[i]) {
        				fprintf(stderr, "Unable to create test file '%s'\n", file_name);
    					break;
				}
				else
				{
        				fprintf(stderr, "open test file[%d] '%s' ok\n", i, file_name);
				}
    
				fseek(filesTest[i], sizeof(struct wav_header), SEEK_SET);
    			}
		}

		inputStreamFlag  = true;
	}
	else
	{
		nearReadSize = 2 * 2 * TEST_FRAMES;
		for(i = 0; i < nearFileNum; i++)
		{
			if(nearFileName[i] != NULL)
			{
				filesNear[i] = fopen(nearFileName[i], "rb");
    				if (!filesNear[i]) {
        				fprintf(stderr, "Unable to open near file '%s'\n", nearFileName[i]);
        				goto exit;
				}
				else{
        				fprintf(stderr, "open near file[%d] '%s' ok\n", i, nearFileName[i]);
				}

				fseek(filesNear[i], sizeof(struct wav_header), SEEK_SET);


				nearBuffer[i] = malloc(nearReadSize + 4);		
				
				if(!nearBuffer[i])
				{
        				fprintf(stderr, "Unable to malloc nearBuffer[%d] \n", i);
					goto exit;	
				}
				else
				{
        				fprintf(stderr, "malloc nearBuffer[%d] 0x%x\n", i, (unsigned int)(nearBuffer[i]));
				}
			}
			else
			{
				filesNear[i] = NULL;
				nearBuffer[i] = NULL;
				fprintf(stderr, "nearFileName[%d] is NULL; is bug ? ... skip\n", i);
			}
		}	
	}
	
	if(resultFileName == NULL)
	{
		fprintf(stderr, "resultFileName is NULL; using output stream.....\n");
		
		//TODO add output stream init
		outputStreamFlag  = true;
	}
	else
	{
		filesResult = fopen(resultFileName, "wb");
    		if (!filesResult) {
        		fprintf(stderr, "Unable to open result file '%s'\n", resultFileName);
			goto exit;
		}
		else{
        		fprintf(stderr, "open result file '%s' ok\n",  resultFileName);
		}

		fseek(filesResult, sizeof(struct wav_header), SEEK_SET);

		resultHeader.riff_id = ID_RIFF;
		resultHeader.riff_sz = 0;
		resultHeader.riff_fmt = ID_WAVE;
		resultHeader.fmt_id = ID_FMT;
		resultHeader.fmt_sz = 16;
		resultHeader.audio_format = FORMAT_PCM;
		resultHeader.num_channels = 1;
		resultHeader.sample_rate = 16000;

		resultHeader.bits_per_sample = 16;
		resultHeader.byte_rate = (resultHeader.bits_per_sample / 8) * resultHeader.num_channels * resultHeader.sample_rate;
		resultHeader.block_align = resultHeader.num_channels * (resultHeader.bits_per_sample / 8);
		resultHeader.data_id = ID_DATA;


		resultReadSize = 2 * resultHeader.num_channels * TEST_FRAMES;
		resultBuffer = malloc(resultReadSize + 4);
		if(!resultBuffer)
		{
        		fprintf(stderr, "Unable to malloc resultBuffer\n");
			goto exit;	
		}
		else
		{
        		fprintf(stderr, "malloc resultBuffer 0x%x\n",  (unsigned int)(resultBuffer));
		}
	}

		
	
	char str1[64];
	char str2[64];
	do{
		memset(cmd, 0, sizeof(cmd));
		fprintf(stderr, "cmd=start\n");
		scanf("%s",cmd);

		fprintf(stderr, "cmd:%s\n",cmd);

		if(strcmp(cmd,"start") == 0)
		{
			break;
		}
		
		usleep(200000);
	}while(1);


	
	fprintf(stderr, "Init Alg ....\n");
	
	if(AECForHostInit() == 0)
		fprintf(stderr, "Init Alg Ok!\n");
	else
		fprintf(stderr, "Init Alg Failed!\n");
	
	if(inputStreamFlag)
	{
		fprintf(stderr, "inputStreamFlag is true; init inputStream!\n");
		if(record_stream_start() == 0)
			fprintf(stderr, "inputStream record_stream_start ok!\n");
		else
			fprintf(stderr, "inputStream record_stream_start failed!\n");

	}
	if(outputStreamFlag)
	{
		fprintf(stderr, "outputStreamFlag is true; init outputStream!\n");
		//TODO add output init
	}

	/* install signal handler and begin capturing */
	signal(SIGINT, sigint_handler); 
	
	do{
		int32_t ret = 0;

		memset(&dataParam, 0, sizeof(struct aecDataParam));

		if(refFileName)
		{
        		ret = fread(refBuffer, 1, (refReadSize), filesRef);
        		if (ret == refReadSize) 
			{
				dataParam.Far = refBuffer;	
			}
			else
			{
				fprintf(stderr, "fread filesRef return %d != refReadSize %d\n", ret, refReadSize);
				break;
			}
		}
		else
		{
			//TODO read ref stream	
			if(localFarFlag )
			{
			
			}
		}

		if(nearFileNum)
		{
			for(i = 0; i< nearFileNum; i++)
			{
				if(nearBuffer[i] && filesNear[i])
				{
        				ret = fread(nearBuffer[i], 1, (nearReadSize), filesNear[i]);
        				if (ret == nearReadSize) 
					{
						dataParam.Near[i] = nearBuffer[i];
					}
					else
					{
						fprintf(stderr, "fread filesNear[%d] return %d != nearReadSize %d\n", i, ret, nearReadSize);
						break;
					}
				}
				else
				{
					fprintf(stderr, "nearBuffer or filesNear is NULL %d, is bug ???? \n", i);
				}
			}		
			
			dataParam.nearNum = nearFileNum;
			dataParam.frames = TEST_FRAMES;
		}
		else
		{
			//TODO read near stream	
			ret = record_stream_read(streamReadBuffer, streamReadSize);
			if(ret == streamReadSize)
			{
				int16_t *p_read;
				int16_t *p_write;
				uint32_t j = 0;
				uint32_t k = 0;

				for(i = 0; i < (recordParam->valid_channels>>1); i++)
				{
					p_read = streamReadBuffer + (i<<1);
					p_write = nearBuffer[i]; 

					for(j = 0; j < recordParam->periodsize; j++)
					{
						*p_write++ = *p_read;
						*p_write++ = *(p_read + 1);

						p_read += recordParam->stream_channels;
					}

					if(streamTestFlag)
					{
						if(filesTest[i])
						{
        						if (fwrite(nearBuffer[i], 1, 2 * 2 * recordParam->periodsize, filesTest[i]) != 2 *2 * recordParam->periodsize) 
							{
								fprintf(stderr, "fwrite fileTest[%d] error \n", i);
							}
							else
							{
							}
						}
						else
						{
							fprintf(stderr, "filesTest[%d] is NULL, is bug ???? \n", i);
						}
					}
					if((recordParam->echo_channels == 0) || (i != (recordParam->echo_offset >> 1)))
						dataParam.Near[k++] = nearBuffer[i];
					else
						dataParam.Far = nearBuffer[i];
				}
			
				if(streamTestFlag)
					testWriteFrames += recordParam->periodsize;
				dataParam.nearNum = (recordParam->valid_channels - recordParam->echo_channels) >> 1;
				dataParam.frames = recordParam->periodsize;
			}
			else
			{
				fprintf(stderr, "inputStream record_stream_read ret[%d] != streamReadSize[%d] \n", ret, streamReadSize);
				break;
			}
		}

		dataParam.Result = resultBuffer;

		ret = AECForHostMain(&dataParam);
		if(ret == 0)
		{
			fprintf(stderr, "AECForHostMain ok!\n");
			if(filesResult)
			{	
        			if (fwrite(resultBuffer, 1, resultReadSize, filesResult) != resultReadSize)
				{

					fprintf(stderr, "write result file failed\n");
				}
				else
				{
					resultWriteFrames += TEST_FRAMES;
				}
			}
			else
			{
				//TODO write output stream ...
			}

		}
		else
		{
			fprintf(stderr, "AECForHostMain Failed %d\n", ret);
		}
	}while(capturing);

	if(filesResult)
	{	
    		/* write header now all information is known */
    		resultHeader.data_sz = resultWriteFrames * resultHeader.block_align;
    		resultHeader.riff_sz = resultHeader.data_sz + sizeof(resultHeader) - 8;
    		fseek(filesResult, 0, SEEK_SET);
    		fwrite(&resultHeader, sizeof(struct wav_header), 1, filesResult);
	}

	if(testWriteFrames)
	{
    		testHeader.data_sz = testWriteFrames * testHeader.block_align;
    		testHeader.riff_sz = testHeader.data_sz + sizeof(testHeader) - 8;

		for(i = 0; i < 5; i++)
		{
			if(filesTest[i])
			{
    				fseek(filesTest[i], 0, SEEK_SET);
    				fwrite(&testHeader, sizeof(struct wav_header), 1, filesTest[i]);
			}	
		}
	}

    	fprintf(stderr, "Close Alg ....\n");
	ForHostAECExit();
	
	if(inputStreamFlag)
	{
		fprintf(stderr, "inputStreamFlag is true; close inputStream!\n");
		record_stream_close();
	}
	if(outputStreamFlag)
	{
		fprintf(stderr, "outputStreamFlag is true; close outputStream!\n");
		//TODO add output close
	}

exit:
	fprintf(stderr, "test exit\n");
	if(resultBuffer)
	{
    		fprintf(stderr, "free resultBuffer ....\n");
    		free(resultBuffer);
	}
	if(streamReadBuffer)
	{
    		fprintf(stderr, "free streamReadBuffer ....\n");
    		free(streamReadBuffer);
	}
	if(filesResult)
	{
    		fprintf(stderr, "close result files ....\n");
    		fclose(filesResult);
	}

	if(refBuffer)
	{
    		fprintf(stderr, "free refBuffer ....\n");
    		free(refBuffer);
	}
	if(filesRef)
	{
    		fprintf(stderr, "close ref files ....\n");
    		fclose(filesRef);
	}

	for(i=0; i < 5; i++)
	{
		if(filesTest[i])
		{
    			fprintf(stderr, "close test files[%d] ....\n", i);
    			fclose(filesTest[i]);
		}	
	}
	for(i = 0; i< nearFileNum; i++)
	{
		if(nearBuffer[i])
		{
    			fprintf(stderr, "free nearBuffer[%d] ....\n", i);
    			free(nearBuffer[i]);
		}	
		
		if(filesNear[i])
		{
    			fprintf(stderr, "close near files[%d] ....\n", i);
    			fclose(filesNear[i]);
		}
	}
	if(pipeFd != -1)
	{
    		fprintf(stderr, "close local Far Pipe files ....\n");
		close(pipeFd);
	}

	return 0;
}
