#include <stdarg.h>
#include <stdio.h>
#include "dlog.h"
#include <linux/signal.h>
#include <sys/time.h>
#include <android/log.h>
//#define ANDROID_CHANGES
void log_print(int level, const char *format, ...)
{
    if (level >= LOG_MIN && level <= LOG_MAX) {
#ifdef ANDROID_CHANGES
        static int levels[5] = {
            ANDROID_LOG_DEBUG, ANDROID_LOG_INFO, ANDROID_LOG_WARN,
            ANDROID_LOG_ERROR, ANDROID_LOG_FATAL
        };
        va_list ap;
        va_start(ap, format);
        __android_log_vprint(levels[level], "LuciService", format, ap);
        va_end(ap);
#else
        static char *levels = "DIWEF";
        va_list ap;
        fprintf(stderr, "%c: ", levels[level]);
        va_start(ap, format);
        vfprintf(stderr, format, ap);
        va_end(ap);
        fputc('\n', stderr);
#endif
    }
}

